package com.example.myapplication111;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.text.Editable;

import android.text.TextWatcher;

import android.widget.EditText;


public class signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }


    public class PhoneNumberFormattingTextWatcher implements TextWatcher {

        private EditText editText;
        private boolean isFormatting;

        public PhoneNumberFormattingTextWatcher(EditText editText) {
            this.editText = editText;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            if (isFormatting) {
                return;
            }

            isFormatting = true;

            // Удаляем все символы, которые не являются цифрами
            String digits = s.toString().replaceAll("[^\\d]", "");
            StringBuilder formatted = new StringBuilder();

            // Добавляем код страны +7
            if (digits.length() > 0) {
                formatted.append("+7");
            }

            // Добавляем открывающую скобку после кода страны, если есть достаточно символов для неё
            if (digits.length() > 1) {
                formatted.append("(");
            }

            // Добавляем первые три цифры номера телефона
            if (digits.length() >= 2) {
                formatted.append(digits.substring(1, 4));
            }

            // Добавляем закрывающую скобку после трёх цифр номера телефона
            if (digits.length() >= 5) {
                formatted.append(")");
            }

            // Добавляем пробел после закрывающей скобки
            if (digits.length() >= 6) {
                formatted.append(" ");
            }

            // Добавляем следующие три цифры номера телефона
            if (digits.length() >= 5) {
                formatted.append(digits.substring(4, 7));
            }

            // Добавляем дефис после трех цифр номера телефона
            if (digits.length() >= 8) {
                formatted.append("-");
            }

            // Добавляем последние две цифры номера телефона
            if (digits.length() >= 7) {
                formatted.append(digits.substring(7, Math.min(digits.length(), 9)));
            }

            // Устанавливаем отформатированный текст в EditText
            editText.setText(formatted.toString());

            // Перемещаем курсор в конец текста
            editText.setSelection(editText.getText().length());

            isFormatting = false;
        }
    }
}

